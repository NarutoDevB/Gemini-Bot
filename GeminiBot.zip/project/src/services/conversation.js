const userHistory = new Map();
const userLimits = new Map();
const userStats = new Map();

export function addToHistory(userId, message, isUser = true) {
  if (!userHistory.has(userId)) {
    userHistory.set(userId, []);
  }
  
  const history = userHistory.get(userId);
  history.push({
    role: isUser ? 'user' : 'assistant',
    content: message,
    timestamp: Date.now()
  });

  // Keep only last 50 messages
  if (history.length > 50) {
    history.shift();
  }

  // Update user stats
  if (!userStats.has(userId)) {
    userStats.set(userId, {
      messageCount: 0,
      lastActive: Date.now(),
      errors: 0
    });
  }
  
  const stats = userStats.get(userId);
  stats.messageCount++;
  stats.lastActive = Date.now();
}

export function getHistory(userId) {
  return userHistory.get(userId) || [];
}

export function clearHistory(userId) {
  userHistory.delete(userId);
}

export function clearAllHistory() {
  userHistory.clear();
  userStats.clear();
}

export function checkRateLimit(userId) {
  // No rate limit for admin
  if (userId === 6652023737) return true;
  
  const now = Date.now();
  const userLimit = userLimits.get(userId) || { count: 0, timestamp: now };
  
  // Reset counter if hour has passed
  if (now - userLimit.timestamp > 3600000) {
    userLimit.count = 0;
    userLimit.timestamp = now;
  }
  
  userLimit.count++;
  userLimits.set(userId, userLimit);
  
  // 50 requests per hour for normal users
  return userLimit.count <= 50;
}

export async function getUserStats() {
  const now = Date.now();
  const activeThreshold = 3600000; // 1 hour
  
  const stats = {
    activeUsers: 0,
    totalMessages: 0,
    errorRate: 0,
    cpuUsage: process.cpuUsage().user / 1000000,
    requestsPerMinute: 0,
    users: [],
    recentActivities: [],
    recentErrors: []
  };
  
  // Calculate stats
  userStats.forEach((userStat, userId) => {
    if (now - userStat.lastActive < activeThreshold) {
      stats.activeUsers++;
    }
    
    stats.totalMessages += userStat.messageCount;
    stats.errorRate += userStat.errors;
    
    stats.users.push({
      id: userId,
      messageCount: userStat.messageCount,
      lastActive: userStat.lastActive
    });
  });
  
  // Calculate error rate percentage
  stats.errorRate = (stats.errorRate / stats.totalMessages * 100) || 0;
  
  // Get recent activities
  const activities = Array.from(userHistory.values())
    .flat()
    .sort((a, b) => b.timestamp - a.timestamp)
    .slice(0, 10)
    .map(msg => `${new Date(msg.timestamp).toISOString()} - ${msg.role}: ${msg.content.substring(0, 50)}...`);
  
  stats.recentActivities = activities;
  
  return stats;
}

export { userLimits };