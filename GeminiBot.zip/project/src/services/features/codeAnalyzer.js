import { formatCode, detectLanguage } from '../utils/codeFormatter.js';

export async function analyzeCode(code) {
  const language = detectLanguage(code);
  const analysis = {
    language,
    complexity: calculateComplexity(code),
    suggestions: generateSuggestions(code, language),
    bestPractices: checkBestPractices(code, language),
    security: analyzeSecurity(code, language)
  };
  
  return formatAnalysisResponse(analysis, code);
}

function calculateComplexity(code) {
  // Analyse de la complexité cyclomatique
  const complexityFactors = {
    conditionals: (code.match(/if|else|switch|case|while|for|&&|\|\|/g) || []).length,
    functions: (code.match(/function|\=\>|\=\s*async/g) || []).length,
    nesting: Math.max(...code.split('\n').map(line => 
      (line.match(/^\s+/g) || [''])[0].length / 2))
  };
  
  return {
    score: complexityFactors.conditionals + complexityFactors.functions + complexityFactors.nesting,
    details: complexityFactors
  };
}

function generateSuggestions(code, language) {
  const suggestions = [];
  
  // Analyse des patterns courants
  if (language === 'javascript') {
    if (code.includes('var ')) {
      suggestions.push('💡 Utilisez const ou let au lieu de var pour une meilleure gestion de la portée');
    }
    if (code.includes('console.log')) {
      suggestions.push('🔍 Pensez à retirer les console.log en production');
    }
  }
  
  return suggestions;
}

function checkBestPractices(code, language) {
  const practices = [];
  
  // Vérification des bonnes pratiques selon le langage
  switch (language) {
    case 'javascript':
      if (!code.includes('use strict')) {
        practices.push('✨ Ajoutez "use strict" pour un code plus sûr');
      }
      break;
    case 'python':
      if (!code.includes('if __name__ == \'__main__\':')) {
        practices.push('🐍 Considérez ajouter un point d\'entrée principal');
      }
      break;
  }
  
  return practices;
}

function analyzeSecurity(code, language) {
  const issues = [];
  
  // Détection des problèmes de sécurité courants
  const securityPatterns = {
    sql: /SELECT.*FROM.*WHERE.*=.*\$|exec\(|eval\(/i,
    xss: /innerHTML|document\.write/,
    injection: /eval\(|new Function\(/
  };
  
  Object.entries(securityPatterns).forEach(([type, pattern]) => {
    if (pattern.test(code)) {
      issues.push(`⚠️ Risque potentiel de ${type}`);
    }
  });
  
  return issues;
}

function formatAnalysisResponse(analysis, code) {
  return `
🔍 Analyse de Code

📝 Langage détecté: ${analysis.language || 'Non détecté'}

💡 Suggestions d'amélioration:
${analysis.suggestions.map(s => `• ${s}`).join('\n')}

✨ Bonnes pratiques:
${analysis.bestPractices.map(p => `• ${p}`).join('\n')}

🛡️ Sécurité:
${analysis.security.map(s => `• ${s}`).join('\n')}

📊 Complexité:
• Score: ${analysis.complexity.score}
• Conditions: ${analysis.complexity.details.conditionals}
• Fonctions: ${analysis.complexity.details.functions}
• Niveaux d'imbrication max: ${analysis.complexity.details.nesting}

${formatCode(code, analysis.language)}
`;
}