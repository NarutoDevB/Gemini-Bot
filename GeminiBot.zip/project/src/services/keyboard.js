export const mainKeyboard = {
  reply_markup: {
    keyboard: [
      ['🧠 Gemini Pro', '⚡ Gemini Flash'],
      ['📸 Vision Mode', '🎭 ChatGPT'],
      ['ℹ️ Aide', '📊 Stats']
    ],
    resize_keyboard: true
  }
};

export const backKeyboard = {
  reply_markup: {
    keyboard: [['↩️ Retour au menu principal']],
    resize_keyboard: true
  }
};

export function createCommandButtons(commands) {
  const buttons = Object.entries(commands).map(([_, cmd]) => ({
    text: cmd.description,
    callback_data: cmd.command
  }));

  return {
    reply_markup: {
      inline_keyboard: chunks(buttons, 2)
    }
  };
}

// Utilitaire pour diviser un tableau en morceaux
function chunks(array, size) {
  const result = [];
  for (let i = 0; i < array.length; i += size) {
    result.push(array.slice(i, i + size));
  }
  return result;
}