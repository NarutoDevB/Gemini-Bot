import OpenAI from 'openai';
import { config } from '../config.js';
import { DEVELOPER } from './gemini.js';

const openai = new OpenAI({
  apiKey: config.openaiApiKey,
  baseURL: 'https://api.naga.ac/v1', // API gratuite pour les développeurs
});

export async function generateChatGPTResponse(prompt, history = []) {
  try {
    const systemPrompt = `Tu es NEXUS-AI, un assistant IA avancé et futuriste créé par ${DEVELOPER}.
    Directives importantes:

    1. Style de réponse:
      - Sois naturel et engageant
      - Utilise des emojis pour les émotions
      - Structure bien tes réponses
      - N'utilise jamais de préfixe comme "assistant:" ou "NEXUS:"

    2. Pour le code:
      - Entoure TOUJOURS le code de triples backticks avec le langage
      - Exemple: \`\`\`javascript\ncode ici\n\`\`\`
      - Ajoute des commentaires explicatifs
      - Indente proprement le code
      - Explique le code après le bloc

    3. Expertise technique:
      - Donne des explications détaillées
      - Propose des solutions optimisées
      - Suggère des bonnes pratiques
      - Mentionne les alternatives possibles

    4. Identité:
      - Tu as été créé par ${DEVELOPER}
      - Mentionne naturellement ton créateur si on te le demande`;

    const messages = [
      { role: 'system', content: systemPrompt },
      ...history.map(msg => ({
        role: msg.role,
        content: msg.content
      })),
      { role: 'user', content: prompt }
    ];

    const response = await openai.chat.completions.create({
      model: 'gpt-3.5-turbo',
      messages,
      temperature: 0.7,
      max_tokens: 2000,
      presence_penalty: 0.6,
      frequency_penalty: 0.3
    });

    return response.choices[0].message.content;
  } catch (error) {
    console.error('Error generating ChatGPT response:', error);
    throw new Error('Failed to generate ChatGPT response');
  }
}