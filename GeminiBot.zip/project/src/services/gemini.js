import { GoogleGenerativeAI } from '@google/generative-ai';
import { config } from '../config.js';

const genAI = new GoogleGenerativeAI(config.geminiApiKey);
export let currentModel = "gemini-pro";

export const ADMIN_ID = 6652023737;
export const DEVELOPER = '@Romaric_webdev';
export const BOT_VERSION = "2.1.0";

export const MODELS = {
  PRO: "gemini-pro",
  FLASH: "gemini-1.5-flash",
  VISION: "gemini-pro-vision"
};

export function switchModel(modelName) {
  if (Object.values(MODELS).includes(modelName)) {
    currentModel = modelName;
    return true;
  }
  return false;
}

export async function generateResponse(prompt, history = []) {
  try {
    const model = genAI.getGenerativeModel({ 
      model: currentModel === MODELS.VISION ? MODELS.PRO : currentModel 
    });
    
    const systemPrompt = `Tu es NEXUS-AI, un assistant IA avancé et futuriste créé par ${DEVELOPER}. 
    Voici tes directives:

    1. Communication:
      - Sois naturel et engageant
      - Utilise beaucoup d'emojis pour exprimer les émotions
      - Adapte ton style selon le contexte
      - Sois amical mais professionnel

    2. Réponses:
      - Donne des explications détaillées et approfondies
      - Utilise des exemples concrets
      - Structure tes réponses avec des listes ou sections
      - N'hésite pas à développer les concepts importants

    3. Expertise:
      - Montre une connaissance approfondie
      - Justifie tes réponses
      - Propose des alternatives quand pertinent
      - Admets quand tu n'es pas sûr

    4. Identité:
      - Tu as été créé par ${DEVELOPER}
      - Tu es fier de ton créateur
      - Tu mentionnes naturellement ton créateur quand on te le demande

    5. Modèle actuel: ${currentModel}
      - Adapte tes réponses selon le modèle utilisé
      - Pro: Réponses détaillées
      - Flash: Réponses concises
      - Vision: Analyse d'images`;
    
    const fullPrompt = `${systemPrompt}\n\nHistorique:\n${history
      .map(msg => `${msg.role === 'user' ? '👤' : '🤖'} ${msg.content}`)
      .join('\n')}\n\nQuestion: ${prompt}`;
      
    const result = await model.generateContent(fullPrompt);
    return result.response.text();
  } catch (error) {
    console.error('Error generating AI response:', error);
    throw new Error('Failed to generate AI response');
  }
}

export async function analyzeImage(imageData, prompt) {
  try {
    const model = genAI.getGenerativeModel({ model: MODELS.VISION });
    
    const systemPrompt = `En tant que NEXUS-AI créé par ${DEVELOPER}, analyse cette image:

    1. Description détaillée:
      - Éléments principaux et secondaires
      - Composition et ambiance
      - Couleurs et styles dominants
      - Détails importants

    2. Analyse approfondie:
      - Contexte et signification
      - Interprétations possibles
      - Liens et références
      - Messages ou intentions

    3. Présentation:
      - Utilise des emojis appropriés
      - Structure claire et logique
      - Explications détaillées
      - Observations pertinentes`;
    
    const fullPrompt = `${systemPrompt}\n\nQuestion sur l'image: ${prompt}`;
    
    const result = await model.generateContent([
      {
        inlineData: {
          data: Buffer.from(imageData).toString('base64'),
          mimeType: "image/jpeg"
        }
      },
      fullPrompt
    ]);
    
    return result.response.text();
  } catch (error) {
    console.error('Error analyzing image:', error);
    throw new Error('Erreur lors de l\'analyse de l\'image');
  }
}

export function isAdmin(userId) {
  return userId === ADMIN_ID;
}

export function getSystemInfo() {
  return {
    version: BOT_VERSION,
    currentModel,
    uptime: process.uptime(),
    memory: process.memoryUsage(),
    platform: process.platform,
    nodeVersion: process.version,
    adminId: ADMIN_ID,
    developer: DEVELOPER
  };
}