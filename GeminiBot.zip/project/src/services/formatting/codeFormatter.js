import MarkdownIt from 'markdown-it';
import hljs from 'highlight.js';

const md = new MarkdownIt({
  highlight: function (str, lang) {
    if (lang && hljs.getLanguage(lang)) {
      try {
        return hljs.highlight(str, { language: lang }).value;
      } catch (__) {}
    }
    return ''; // use external default escaping
  }
});

export function formatCodeBlock(code, language = '') {
  // Nettoie le code et ajoute la coloration syntaxique
  const formattedCode = code.trim();
  const codeBlock = `\`\`\`${language}\n${formattedCode}\n\`\`\``;
  
  // Ajoute un bouton de copie
  return {
    text: md.render(codeBlock),
    reply_markup: {
      inline_keyboard: [[
        { text: '📋 Copier le code', callback_data: `copy_${Buffer.from(formattedCode).toString('base64')}` }
      ]]
    }
  };
}

export function detectLanguage(code) {
  const patterns = {
    javascript: /(const|let|var|function|=>)/,
    python: /(def|import|from|class|if __name__)/,
    java: /(public|class|void|private|protected)/,
    php: /(<\?php|\$[a-zA-Z_])/,
    html: /(<html|<div|<p|<body)/,
    css: /({[\s\S]*}|@media|@keyframes)/,
    sql: /(SELECT|INSERT|UPDATE|DELETE|CREATE TABLE)/i,
    typescript: /(interface|type|namespace|enum)/,
    rust: /(fn|impl|struct|enum|pub|use)/,
    go: /(func|package|import|type|struct)/,
    ruby: /(def|class|module|require|gem)/
  };

  for (const [lang, pattern] of Object.entries(patterns)) {
    if (pattern.test(code)) return lang;
  }
  
  return 'plaintext';
}