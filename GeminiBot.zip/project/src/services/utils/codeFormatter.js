// Utilitaire pour le formatage du code
export function formatCode(code, language = '') {
  const formattedCode = code.trim();
  return `\`\`\`${language}\n${formattedCode}\n\`\`\``;
}

export function detectLanguage(code) {
  // Détection automatique du langage basée sur les mots-clés et la syntaxe
  const patterns = {
    javascript: /(const|let|var|function|=>)/,
    python: /(def|import|from|class|if __name__)/,
    java: /(public|class|void|private|protected)/,
    php: /(<\?php|\$[a-zA-Z_])/,
    html: /(<html|<div|<p|<body)/,
    css: /({[\s\S]*}|@media|@keyframes)/,
    sql: /(SELECT|INSERT|UPDATE|DELETE|CREATE TABLE)/i
  };

  for (const [lang, pattern] of Object.entries(patterns)) {
    if (pattern.test(code)) return lang;
  }
  
  return '';
}