import TelegramBot from 'node-telegram-bot-api';
import { config } from './config.js';
import { generateResponse, analyzeImage, MODELS, switchModel } from './services/gemini.js';
import { generateChatGPTResponse } from './services/openai.js';
import { addToHistory, getHistory, checkRateLimit } from './services/conversation.js';
import { commands } from './commands/index.js';
import { mainKeyboard, backKeyboard } from './services/keyboard.js';
import { formatCodeBlock } from './services/formatting/codeFormatter.js';

let currentAIModel = 'gemini';

export function initializeBot() {
  const bot = new TelegramBot(config.telegramToken, { polling: true });

  // Register command handlers
  Object.entries(commands).forEach(([name, cmd]) => {
    bot.onText(new RegExp(`^${cmd.command}($| .*$)`), (msg, match) => {
      const chatId = msg.chat.id;
      const userId = msg.from.id;
      cmd.handler(bot, chatId, userId, msg, match);
    });
  });

  // Handle callback queries (boutons inline)
  bot.on('callback_query', async (query) => {
    const chatId = query.message.chat.id;
    
    if (query.data.startsWith('copy_')) {
      const code = Buffer.from(query.data.replace('copy_', ''), 'base64').toString();
      await bot.answerCallbackQuery(query.id, { text: '✅ Code copié!' });
      await bot.sendMessage(chatId, code, { parse_mode: 'HTML' });
    } else {
      const command = commands[query.data.replace('/', '')];
      if (command) {
        command.handler(bot, chatId, query.from.id);
      }
    }
  });

  // Handle text messages
  bot.on('message', async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const userMessage = msg.text;

    // Skip command messages
    if (userMessage?.startsWith('/')) return;

    try {
      // Check rate limit
      if (!checkRateLimit(userId)) {
        await bot.sendMessage(
          chatId,
          '⚠️ Vous avez atteint la limite de requêtes horaire. Veuillez réessayer plus tard.',
          mainKeyboard
        );
        return;
      }

      // Handle keyboard buttons
      if (userMessage === '🧠 Gemini Pro') {
        currentAIModel = 'gemini';
        switchModel(MODELS.PRO);
        await bot.sendMessage(
          chatId,
          '🧠 Mode Gemini Pro activé\n\nJe suis prêt à répondre à vos questions de manière détaillée!',
          backKeyboard
        );
        return;
      }

      if (userMessage === '⚡ Gemini Flash') {
        currentAIModel = 'gemini';
        switchModel(MODELS.FLASH);
        await bot.sendMessage(
          chatId,
          '⚡ Mode Gemini Flash activé\n\nJe suis prêt pour des réponses rapides et concises!',
          backKeyboard
        );
        return;
      }

      if (userMessage === '📸 Vision Mode') {
        currentAIModel = 'gemini';
        switchModel(MODELS.VISION);
        await bot.sendMessage(
          chatId,
          '📸 Mode Vision activé\n\nEnvoyez-moi une image à analyser!',
          backKeyboard
        );
        return;
      }

      if (userMessage === '🎭 ChatGPT') {
        currentAIModel = 'chatgpt';
        await bot.sendMessage(
          chatId,
          '🎭 Mode ChatGPT activé\n\nJe suis prêt à discuter avec vous!',
          backKeyboard
        );
        return;
      }

      if (userMessage === '↩️ Retour au menu principal') {
        await bot.sendMessage(
          chatId,
          '🌟 Menu Principal\n\nChoisissez un mode de conversation:',
          mainKeyboard
        );
        return;
      }

      // Handle image messages
      if (msg.photo) {
        await bot.sendChatAction(chatId, 'typing');
        const photo = msg.photo[msg.photo.length - 1];
        const fileLink = await bot.getFileLink(photo.file_id);
        const imageResponse = await fetch(fileLink);
        const imageData = await imageResponse.arrayBuffer();
        
        const caption = msg.caption || 'Que voyez-vous dans cette image?';
        const response = await analyzeImage(imageData, caption);
        await bot.sendMessage(chatId, response, backKeyboard);
        addToHistory(userId, 'Image envoyée: ' + caption, true);
        addToHistory(userId, response, false);
        return;
      }

      // Handle text messages
      if (userMessage) {
        await bot.sendChatAction(chatId, 'typing');
        
        addToHistory(userId, userMessage, true);
        const history = getHistory(userId);
        
        let response;
        if (currentAIModel === 'chatgpt') {
          response = await generateChatGPTResponse(userMessage, history);
        } else {
          response = await generateResponse(userMessage, history);
        }

        // Détecte et formate les blocs de code dans la réponse
        if (response.includes('```')) {
          const parts = response.split(/(```[\s\S]*?```)/g);
          for (const part of parts) {
            if (part.startsWith('```')) {
              const [, lang, code] = part.match(/```(\w*)\n([\s\S]*?)```/) || [, '', part.slice(3, -3)];
              const formattedCode = formatCodeBlock(code, lang);
              await bot.sendMessage(chatId, formattedCode.text, {
                parse_mode: 'HTML',
                reply_markup: formattedCode.reply_markup
              });
            } else if (part.trim()) {
              await bot.sendMessage(chatId, part, backKeyboard);
            }
          }
        } else {
          await bot.sendMessage(chatId, response, backKeyboard);
        }

        addToHistory(userId, response, false);
      }
    } catch (error) {
      console.error('Error handling message:', error);
      await bot.sendMessage(
        chatId, 
        "Désolé, une erreur est survenue lors du traitement de votre message.",
        mainKeyboard
      );
    }
  });

  return bot;
}