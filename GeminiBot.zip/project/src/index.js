import { initializeBot } from './bot.js';

console.log('🚀 Initialisation du système NEXUS-AI...');
console.log('📡 Connexion aux serveurs en cours...');

try {
  const bot = initializeBot();
  console.log('✨ NEXUS-AI est en ligne et prêt à interagir!');
  console.log('🤖 Système opérationnel - En attente des communications...');
} catch (error) {
  console.error('❌ Erreur critique lors du démarrage:', error);
  process.exit(1);
}