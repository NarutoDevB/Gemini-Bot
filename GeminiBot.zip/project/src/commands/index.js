import { adminCommands } from './admin.js';
import { devCommands } from './dev.js';
import { DEVELOPER, isAdmin, getSystemInfo } from '../services/gemini.js';
import { clearHistory, userLimits } from '../services/conversation.js';
import { mainKeyboard, createCommandButtons } from '../services/keyboard.js';

const baseCommands = {
  start: {
    command: '/start',
    description: '🚀 Démarrer',
    handler: (bot, chatId) => {
      const message = `
🌟 ==================================== 🌟

    [ NEXUS-AI v2.0 - ASSISTANT INTELLIGENT ]

🤖 Initialisation du système...
✨ Connexion établie avec succès!

Bonjour! Je suis NEXUS, votre assistant IA nouvelle génération créé par ${DEVELOPER}. Je suis équipé des dernières avancées en intelligence artificielle pour vous assister dans toutes vos tâches.

🎯 CAPACITÉS PRINCIPALES:
└─🧠 Analyse contextuelle avancée
└─🖼️ Vision artificielle (Gemini Pro Vision)
└─💡 Génération de contenu créatif
└─🔄 Apprentissage adaptatif
└─🎭 ChatGPT intégré
└─💻 Analyse de code avancée

⚡ COMMANDES SYSTÈME:
└─📲 /start     - Initialiser le système
└─ℹ️ /help      - Protocoles d'assistance
└─🗑️ /clear     - Purger la mémoire cache
└─📊 /stats     - Statistiques système
└─👑 /dev       - Menu développeur
└─🔍 /analyze   - Analyser du code
└─📸 /vision    - Analyse technique d'image
└─⚡ /benchmark - Test de performance

🌐 MODE D'INTERACTION:
└─💬 Messages textuels
└─📸 Analyse d'images
└─🤝 Dialogue contextuel
└─🎭 ChatGPT disponible
└─💻 Analyse de code

💻 DÉVELOPPEUR: ${DEVELOPER}

[ SYSTÈME PRÊT - EN ATTENTE DE VOS INSTRUCTIONS ]

🌟 ==================================== 🌟`;

      // Crée les boutons de commande
      const commandButtons = createCommandButtons({
        ...baseCommands,
        ...devCommands,
        ...(isAdmin(chatId) ? adminCommands : {})
      });

      // Envoie le message avec les boutons
      return bot.sendMessage(chatId, message, {
        ...mainKeyboard,
        reply_markup: {
          ...mainKeyboard.reply_markup,
          inline_keyboard: [
            ...commandButtons.reply_markup.inline_keyboard
          ]
        }
      });
    }
  },
  
  help: {
    command: '/help',
    description: 'ℹ️ Aide',
    handler: (bot, chatId) => {
      const message = `
🌟 [ NEXUS-AI - PROTOCOLES D'ASSISTANCE ] 🌟

📡 FONCTIONNALITÉS PRINCIPALES:

1️⃣ TRAITEMENT DU LANGAGE
└─📝 Questions complexes
└─💭 Analyse sémantique
└─📚 Génération de contenu
└─🎭 Support ChatGPT

2️⃣ VISION ARTIFICIELLE
└─🖼️ Analyse d'images
└─🎨 Reconnaissance visuelle
└─📊 Interprétation contextuelle
└─💻 Détection de code

3️⃣ MODÈLES DISPONIBLES
└─🧠 Gemini Pro - Standard
└─⚡ Gemini Flash - Rapide
└─📸 Vision - Images
└─🎭 ChatGPT - GPT-3.5 Turbo

4️⃣ DÉVELOPPEMENT
└─🔍 Analyse de code
└─📊 Métriques de complexité
└─🛡️ Audit de sécurité
└─💡 Suggestions d'amélioration

5️⃣ SYSTÈME AVANCÉ
└─💾 Historique conversationnel
└─🔄 Apprentissage continu
└─🎯 Réponses personnalisées
└─🤝 Multi-modèles IA

⚡ COMMANDES SYSTÈME:
┌────────────────────────────┐
│ /start     - Boot système  │
│ /help      - Guide         │
│ /clear     - Reset mémoire │
│ /stats     - Statistiques  │
│ /dev       - Menu dev      │
│ /analyze   - Analyse code  │
│ /vision    - Analyse image │
│ /benchmark - Performance   │
└────────────────────────────┘

💻 DÉVELOPPEUR: ${DEVELOPER}`;

      return bot.sendMessage(chatId, message, mainKeyboard);
    }
  },
  
  clear: {
    command: '/clear',
    description: '🗑️ Effacer',
    handler: (bot, chatId, userId) => {
      clearHistory(userId);
      return bot.sendMessage(chatId, `
🌟 [ PURGE SYSTÈME EFFECTUÉE ] 🌟

✨ Mémoire cache effacée
✨ Historique conversationnel réinitialisé
✨ Système prêt pour nouvelle session

[ STATUT: OPÉRATIONNEL ]`, mainKeyboard);
    }
  },
  
  stats: {
    command: '/stats',
    description: '📊 Stats',
    handler: (bot, chatId) => {
      const systemInfo = getSystemInfo();
      const activeUsers = userLimits.size;
      const hours = Math.floor(systemInfo.uptime / 3600);
      const minutes = Math.floor((systemInfo.uptime % 3600) / 60);
      
      const message = `
📊 [ STATISTIQUES SYSTÈME ] 📊

💻 PERFORMANCES:
└─👥 Utilisateurs actifs: ${activeUsers}
└─⚡ Version: ${systemInfo.version}
└─⏱️ Uptime: ${hours}h ${minutes}m
└─🔄 Status: Opérationnel

🧠 MODÈLES DISPONIBLES:
└─💭 Gemini Pro: Standard
└─⚡ Gemini Flash: Rapide
└─📸 Vision: Analyse d'images
└─🎭 ChatGPT: GPT-3.5 Turbo

⚙️ SYSTÈME:
└─💾 RAM: ${Math.round(systemInfo.memory.heapUsed / 1024 / 1024)}MB
└─💻 Platform: ${systemInfo.platform}
└─📦 Node.js: ${systemInfo.nodeVersion}

👑 ADMINISTRATION:
└─👤 Admin ID: ${systemInfo.adminId}
└─👨‍💻 Développeur: ${systemInfo.developer}

[ DÉVELOPPEUR: ${DEVELOPER} ]`;
      
      return bot.sendMessage(chatId, message, mainKeyboard);
    }
  }
};

export const commands = {
  ...baseCommands,
  ...adminCommands,
  ...devCommands
};