import { isAdmin, getSystemInfo } from '../services/gemini.js';
import { clearAllHistory, getUserStats } from '../services/conversation.js';
import { mainKeyboard } from '../services/keyboard.js';

export const adminCommands = {
  dev: {
    command: '/dev',
    description: 'Menu développeur',
    handler: async (bot, chatId, userId) => {
      if (!isAdmin(userId)) {
        return bot.sendMessage(chatId, '⛔ Accès refusé: Droits administrateur requis', mainKeyboard);
      }
      
      const systemInfo = getSystemInfo();
      const stats = await getUserStats();
      
      const message = `
👑 [ PANNEAU ADMINISTRATEUR ] 👑

🔧 SYSTÈME:
└─📊 Version: ${systemInfo.version}
└─💾 RAM: ${Math.round(systemInfo.memory.heapUsed / 1024 / 1024)}MB
└─⚡ CPU: ${systemInfo.platform}
└─⏱️ Uptime: ${Math.floor(systemInfo.uptime / 3600)}h ${Math.floor((systemInfo.uptime % 3600) / 60)}m

👥 STATISTIQUES:
└─👤 Utilisateurs actifs: ${stats.activeUsers}
└─💭 Messages totaux: ${stats.totalMessages}
└─📊 Taux d'erreur: ${stats.errorRate}%
└─📈 Utilisation CPU: ${stats.cpuUsage}%

⚙️ CONFIGURATION:
└─🤖 Modèle: ${systemInfo.currentModel}
└─👑 Admin ID: ${systemInfo.adminId}
└─👨‍💻 Développeur: ${systemInfo.developer}

[ SYSTÈME NEXUS-AI v${systemInfo.version} ]`;

      // Boutons de commandes admin
      const adminButtons = {
        reply_markup: {
          inline_keyboard: [
            [
              { text: '🔄 Redémarrer', callback_data: '/restart' },
              { text: '🗑️ Purger', callback_data: '/purge' }
            ],
            [
              { text: '📊 Stats', callback_data: '/stats' },
              { text: '⚙️ Config', callback_data: '/config' }
            ],
            [
              { text: '🔒 Ban', callback_data: '/ban' },
              { text: '✅ Unban', callback_data: '/unban' }
            ],
            [
              { text: '📢 Broadcast', callback_data: '/broadcast' },
              { text: '📝 Logs', callback_data: '/logs' }
            ]
          ]
        }
      };
      
      return bot.sendMessage(chatId, message, adminButtons);
    }
  },

  broadcast: {
    command: '/broadcast',
    description: 'Message global',
    handler: async (bot, chatId, userId, msg, match) => {
      if (!isAdmin(userId)) {
        return bot.sendMessage(chatId, '⛔ Accès refusé', mainKeyboard);
      }

      // Si pas de message, demander le message
      if (!match || !match[1]) {
        const instructions = `
📢 [ BROADCAST MESSAGE ]

Pour envoyer un message à tous les utilisateurs:
1️⃣ Tapez votre message
2️⃣ Utilisez les balises disponibles:
  • {name} - Nom de l'utilisateur
  • {id} - ID de l'utilisateur
  • {date} - Date actuelle

Exemple:
/broadcast Bonjour {name} ! Mise à jour importante...

Options:
• /broadcast preview <message> - Prévisualiser
• /broadcast send <message> - Envoyer
• /broadcast cancel - Annuler`;

        return bot.sendMessage(chatId, instructions, mainKeyboard);
      }

      const [command, ...messageParts] = match[1].trim().split(' ');
      const message = messageParts.join(' ');

      // Prévisualisation du message
      if (command === 'preview') {
        const preview = formatBroadcastMessage(message, {
          name: 'Utilisateur Test',
          id: '123456789',
          date: new Date().toLocaleDateString()
        });

        return bot.sendMessage(chatId, `
📢 [ PRÉVISUALISATION ]

${preview}

Pour envoyer: /broadcast send ${message}
Pour annuler: /broadcast cancel`, mainKeyboard);
      }

      // Envoi du message
      if (command === 'send') {
        const stats = await getUserStats();
        let sent = 0;
        let failed = 0;

        const progress = await bot.sendMessage(chatId, '📤 Envoi en cours...');

        for (const user of stats.users) {
          try {
            const formattedMessage = formatBroadcastMessage(message, {
              name: user.name || 'Utilisateur',
              id: user.id,
              date: new Date().toLocaleDateString()
            });

            await bot.sendMessage(user.id, formattedMessage);
            sent++;

            // Mise à jour du progrès tous les 10 messages
            if (sent % 10 === 0) {
              await bot.editMessageText(
                `📤 Envoi en cours... ${sent}/${stats.users.length}`,
                { chat_id: chatId, message_id: progress.message_id }
              );
            }
          } catch (error) {
            console.error(`Failed to send broadcast to user ${user.id}:`, error);
            failed++;
          }
        }

        return bot.sendMessage(chatId, `
✅ Broadcast terminé

📊 Statistiques:
• ✅ Envoyés: ${sent}
• ❌ Échecs: ${failed}
• 👥 Total: ${stats.users.length}`, mainKeyboard);
      }

      // Annulation
      if (command === 'cancel') {
        return bot.sendMessage(chatId, '❌ Broadcast annulé', mainKeyboard);
      }

      return bot.sendMessage(chatId, '⚠️ Commande invalide. Utilisez preview, send ou cancel.', mainKeyboard);
    }
  },

  restart: {
    command: '/restart',
    description: 'Redémarrer le bot',
    handler: async (bot, chatId, userId) => {
      if (!isAdmin(userId)) {
        return bot.sendMessage(chatId, '⛔ Accès refusé', mainKeyboard);
      }
      
      await bot.sendMessage(chatId, '🔄 Redémarrage du système...', mainKeyboard);
      process.exit(0);
    }
  },

  purge: {
    command: '/purge',
    description: 'Purger les données',
    handler: async (bot, chatId, userId) => {
      if (!isAdmin(userId)) {
        return bot.sendMessage(chatId, '⛔ Accès refusé', mainKeyboard);
      }
      
      await clearAllHistory();
      await bot.sendMessage(chatId, '🗑️ Toutes les données ont été purgées', mainKeyboard);
    }
  }
};

function formatBroadcastMessage(message, user) {
  return message
    .replace(/{name}/g, user.name)
    .replace(/{id}/g, user.id)
    .replace(/{date}/g, user.date);
}