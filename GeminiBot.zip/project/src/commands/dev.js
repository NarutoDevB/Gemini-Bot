import { isAdmin } from '../services/gemini.js';
import { analyzeCode } from '../services/features/codeAnalyzer.js';
import { enhanceImageAnalysis } from '../services/features/imageEnhancer.js';

export const devCommands = {
  analyze: {
    command: '/analyze',
    description: 'Analyser du code',
    handler: async (bot, chatId, userId, msg) => {
      if (!msg.reply_to_message?.text) {
        return bot.sendMessage(chatId, 
          '⚠️ Veuillez répondre à un message contenant du code à analyser');
      }
      
      const analysis = await analyzeCode(msg.reply_to_message.text);
      return bot.sendMessage(chatId, analysis, { parse_mode: 'Markdown' });
    }
  },

  vision: {
    command: '/vision',
    description: 'Analyse technique d\'image',
    handler: async (bot, chatId, userId, msg) => {
      if (!msg.reply_to_message?.photo) {
        return bot.sendMessage(chatId, 
          '⚠️ Veuillez répondre à une image à analyser');
      }
      
      const photo = msg.reply_to_message.photo[msg.reply_to_message.photo.length - 1];
      const fileLink = await bot.getFileLink(photo.file_id);
      const imageResponse = await fetch(fileLink);
      const imageData = await imageResponse.arrayBuffer();
      
      const analysis = await enhanceImageAnalysis(
        imageData,
        msg.reply_to_message.caption || 'Analyse technique requise'
      );
      
      return bot.sendMessage(chatId, analysis);
    }
  },

  benchmark: {
    command: '/benchmark',
    description: 'Test de performance',
    handler: async (bot, chatId, userId) => {
      if (!isAdmin(userId)) {
        return bot.sendMessage(chatId, '⛔ Accès refusé');
      }
      
      const start = process.hrtime();
      const memory = process.memoryUsage();
      
      const stats = {
        uptime: process.uptime(),
        memory: {
          heapUsed: Math.round(memory.heapUsed / 1024 / 1024),
          heapTotal: Math.round(memory.heapTotal / 1024 / 1024),
          external: Math.round(memory.external / 1024 / 1024)
        },
        cpu: process.cpuUsage()
      };
      
      const [seconds, nanoseconds] = process.hrtime(start);
      const duration = seconds + nanoseconds / 1e9;
      
      const report = `
📊 Rapport de Performance

⏱️ Temps d'exécution: ${duration.toFixed(3)}s

💾 Mémoire:
• Utilisée: ${stats.memory.heapUsed}MB
• Totale: ${stats.memory.heapTotal}MB
• Externe: ${stats.memory.external}MB

⚡ CPU:
• User: ${stats.cpu.user}
• System: ${stats.cpu.system}

🕒 Uptime: ${Math.floor(stats.uptime / 3600)}h ${Math.floor((stats.uptime % 3600) / 60)}m
`;
      
      return bot.sendMessage(chatId, report);
    }
  }
};